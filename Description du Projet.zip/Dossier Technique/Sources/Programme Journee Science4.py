import pyxel
import math
from copy import deepcopy
from random import randint


fenetre_x, fenetre_y = 672, 448 + 32
pyxel.init(fenetre_x, fenetre_y, title="Nuit du c0de")
pyxel.load("JourneeSC.pyxres", True, True, True, True)
pyxel.mouse(True)

class Boule:

    def __init__(self, x, y, diametre, couleur, raye):

        self.x = x
        self.y = y

        self.rayon = diametre/2
        self.diametre = diametre

        self.couleur = couleur
        self.raye = raye

        self.vitesse_x = 0
        self.vitesse_y = 0

    def ralentissement(self):

        self.vitesse_x *= 0.95
        self.vitesse_y *= 0.95

        if self.vitesse_x > -0.1 and self.vitesse_x < 0.1:
            
            self.vitesse_x = 0

        if self.vitesse_y > -0.1 and self.vitesse_y < 0.1:
            
            self.vitesse_y = 0
    
    def inverse_ralentissement(self):
        
        self.vitesse_x /= 0.95
        self.vitesse_y /= 0.95

    def deplacement(self):

        self.x += self.vitesse_x
        self.y += self.vitesse_y

        self.ralentissement()
    
    def en_mouvement(self):
        
        return self.vitesse_x != 0 or self.vitesse_y != 0
 
    def affiche(self):
        
        pyxel.blt(self.x - self.rayon, self.y - self.rayon, 0, (24 + 8) * self.couleur, 72 + (24 + 8) * self.raye,25, 25, 1)

def recadrement(boule, fenetre_x, fenetre_y):

    if boule.x - boule.rayon < 32:
        
        boule.x = 32 + boule.rayon
        boule.vitesse_x *= -0.75
        
        pyxel.play(0,4)

    elif boule.x + boule.rayon > fenetre_x - 32:
        
        boule.x = fenetre_x - 32 - boule.rayon
        boule.vitesse_x *= -0.75
        
        pyxel.play(0,4)

    if boule.y - boule.rayon < 32 + 32:
        
        boule.y = 32 + 32 + boule.rayon
        boule.vitesse_y *= -0.75
        
        pyxel.play(0,4)

    elif boule.y + boule.rayon > fenetre_y - 32:
        
        boule.y = fenetre_y - 32 - boule.rayon
        boule.vitesse_y *= -0.75
        
        pyxel.play(0,4)
        
def equation_canonique(a,b,c):

    delta = b**2 - 4*a*c
    
    if delta < 0:
        
        return 0, 0
    
    elif delta == 0:
        
        return 1, -b/(2*a)
    
    else:
        
        return 2, (-b - math.sqrt(delta))/(2*a), (-b + math.sqrt(delta))/(2*a)

def test_trou(objet):
    
    #On ne prend en compte que le centre du cercle pour "simuler" de la gravité
    if (objet.x > 3.3 * 8 and objet.x < 6.7 * 8) and (objet.y > 32 + 3.3 * 8 and objet.y < 32 + 6.7 * 8):
        
        return True
    
    elif (objet.x > 3.3 * 8 and objet.x < 6.7 * 8) and (objet.y > 32 + 49.3 * 8 and objet.y < 32 + 52.7 * 8):
        
        return True
    
    elif (objet.x > 40.3 * 8 and objet.x < 43.7 * 8) and (objet.y > 32 + 3.3 * 8 and objet.y < 32 + 6.7 * 8):
        
        return True
    
    elif (objet.x > 40.3 * 8 and objet.x < 43.7 * 8) and (objet.y > 32 + 49.3 * 8 and objet.y < 32 + 52.7 * 8):
        
        return True
    
    elif (objet.x > 77.3 * 8 and objet.x < 80.7 * 8) and (objet.y > 32 + 3.3 * 8 and objet.y < 32 + 6.7 * 8):
        
        return True
    
    elif (objet.x > 77.3 * 8 and objet.x < 80.7 * 8) and (objet.y > 32 + 49.3 * 8 and objet.y < 32 + 52.7 * 8):
        
        return True
    
def pente(x1, y1, x2, y2):
    
    if x2 - x1 == 0:
        
        return (y2 - y1)/0.0000001
    
    return (y2 - y1)/(x2 - x1)

def ordonne_origine(x1, y1, x2, y2):

    return y2 - pente(x1, y1, x2, y2) * x2

def maxi_val(a, b):

    if a > b:
        
        return a
    
    else:
        
        return b

def min_val(a, b):

    if a < b:
        
        return a
    
    else:
        
        return b

def intersection_cercle(x1, y1, x2, y2, pos_x_cercle, pos_y_cercle, diametre):

    #Alors tout cela vient du fait qu'on a une equation du type y = ax + b
    #Car on veut trouver le point d'intersection entre cette droite, et un cercle qui fait deux fois la taille du cercle dont on cherche la collision
    #Deux fois car on cherche le/les points de collision entre la boule et l'autre (Voir schéma1)
    #Ensuite si on résoud, on obtient les valeurs ci-dessous (voir schéma2)
    
    Pente = pente(x1, y1, x2, y2)
    Ordonne_origine = ordonne_origine(x1, y1, x2, y2)
    a = (Pente**2 + 1)
    b = (2*(Pente*(Ordonne_origine - pos_y_cercle) - pos_x_cercle))
    c = (Ordonne_origine * (Ordonne_origine - 2*pos_y_cercle) - diametre**2 + pos_y_cercle**2 + pos_x_cercle**2)
    
    return equation_canonique(a,b,c)

def collision_cercle(objet_1, objet_2):
    
    return math.sqrt((objet_1.x - objet_2.x)**2 + (objet_1.y - objet_2.y)**2) < 25/2*2

#Initialisation
##########################################
Boule_Blanche = Boule(504 - 25 / 2, 32 + 224 - 25 / 2, 25, 0, 0)
Triangle_Boules = [Boule_Blanche]
#Pour comprendre d'où vient 21.66, (voir schéma4), (J'ai arrondi par excès pour éviter des collisions)
espacement_x = 21.66
espacement_y = 12.5
x_boule_1 = 168 + 25 * 5 - 25 / 2
y_boule_1 = 32 + 224 - 25 / 2
numero = 0

for rangee_x in range(5):
    
    for rangee_y in range(rangee_x + 1):
        
        numero += 1
        Triangle_Boules.append(Boule(x_boule_1 - (espacement_x * rangee_x), y_boule_1 + (espacement_y * (2 * rangee_y - rangee_x)), 25, numero % 8, int(numero / 8)))

dico_bool = {"autorisation_de_passer_au_tour_suivant": True, "tour_suivant": False, "boule_blanche_en_main": False, "en_train_de_tirer": False, "clic_maintenu": False}
#Creation de la liste des Variables Globales
global G
G = {"taille": {"fenetre_x": fenetre_x, "fenetre_y": fenetre_y}, "Liste_Objets": Triangle_Boules, "boule_blanche": Triangle_Boules[0], "boules marquees": {"equipe_1": [], "equipe_2": []}, "b": dico_bool, "position_curseur_origine": [0, 0], "clic": True, "Equipe": True, "Raye Equipe": True, "Boule Marquee": False, "Victoire_Joueur_1": False, "Victoire_Joueur_2": False}

#Création des fonctions de clarification
def pas_encore_de_gagnant():
    
    return not(G["Victoire_Joueur_1"] or G["Victoire_Joueur_2"])

def collision_entre_la_souris_et_la_boule_blanche():
    
    return (pyxel.mouse_x > G["boule_blanche"].x - G["boule_blanche"].rayon and pyxel.mouse_x < G["boule_blanche"].x + G["boule_blanche"].rayon) and (pyxel.mouse_y > G["boule_blanche"].y - G["boule_blanche"].rayon and pyxel.mouse_y < G["boule_blanche"].y + G["boule_blanche"].rayon)

def la_vitesse_absolue_de_la_balle_est_superieure_a_35():
    
    return G["boule_blanche"].vitesse_x < -35 or G["boule_blanche"].vitesse_x > 35 or G["boule_blanche"].vitesse_y < -35 or G["boule_blanche"].vitesse_y > 35

def ralentissement(a,b):
    
    return 0.95 * a, 0.95 * b

def angle_entre_la_souris_et_la_boule_blanche(vecteur):
    
    if vecteur[0] == 0:
                
        if vecteur[1] > 0:
            
            angle = math.pi / 2
            
        else:
            
            angle = -math.pi / 2
            
    else:
        
        angle = math.atan(vecteur[1]/vecteur[0])
    
    return angle

##########################################
boule_blanche_rentree = False
aucune_boule_touchee = True
mauvaise_boule_touchee_en_premier = False
premiere_boule_touchee_verifiee = False
musique_ecran_victoire = True
def update():
    global G, boule_blanche_rentree, aucune_boule_touchee, boule_touchee_a_ce_tour, mauvaise_boule_touchee_en_premier, premiere_boule_touchee_verifiee, musique_ecran_victoire
    
    blanc = 0
    noir = 7
    
    if pas_encore_de_gagnant():
        
        Toutes_les_boules_arretees = not(any(boule.en_mouvement() for boule in G["Liste_Objets"]))
        
        if Toutes_les_boules_arretees:
            
            if G["b"]["autorisation_de_passer_au_tour_suivant"]:
                
                G["b"]["tour_suivant"] = True
                G["b"]["autorisation_de_passer_au_tour_suivant"] = False
                
        if pyxel.btn(pyxel.MOUSE_BUTTON_LEFT):
            
            if boule_blanche_rentree or aucune_boule_touchee or mauvaise_boule_touchee_en_premier:
                
                if not(G["b"]["boule_blanche_en_main"]):
                    
                    if not(G["b"]["en_train_de_tirer"]) and collision_entre_la_souris_et_la_boule_blanche():
                        
                        G["b"]["boule_blanche_en_main"] = True
                        
                    else:
                        
                        if Toutes_les_boules_arretees:
                            
                            if not(G["b"]["clic_maintenu"]):
                                
                                G["position_boule_blanche"] = [G["boule_blanche"].x, G["boule_blanche"].y]
                                G["position_du_curseur_au_debut_du_tir"] = [pyxel.mouse_x, pyxel.mouse_y]
                                
                            G["b"]["clic_maintenu"] = True

                else:
                    
                    G["boule_blanche"].x = pyxel.mouse_x
                    G["boule_blanche"].y = pyxel.mouse_y
                    
            else:
                
                if Toutes_les_boules_arretees:
                    
                    if not(G["b"]["clic_maintenu"]):
                        
                        G["position_boule_blanche"] = [G["boule_blanche"].x, G["boule_blanche"].y]
                        G["position_du_curseur_au_debut_du_tir"] = [pyxel.mouse_x, pyxel.mouse_y]
                        
                    G["b"]["clic_maintenu"] = True
        
        if pyxel.btnr(pyxel.MOUSE_BUTTON_LEFT):
            
            if G["b"]["boule_blanche_en_main"]:
                
                G["b"]["boule_blanche_en_main"] = False
            
            else:
                
                if Toutes_les_boules_arretees:
                    
                    position_x_du_curseur_au_debut_du_tir = G["position_du_curseur_au_debut_du_tir"][0]
                    position_y_du_curseur_au_debut_du_tir = G["position_du_curseur_au_debut_du_tir"][1]
                    
                    vecteur_deplacement_boule_blanche = [position_x_du_curseur_au_debut_du_tir - pyxel.mouse_x, position_y_du_curseur_au_debut_du_tir - pyxel.mouse_y]
                    
                    G["boule_blanche"].vitesse_x = vecteur_deplacement_boule_blanche[0] / 8
                    G["boule_blanche"].vitesse_y = vecteur_deplacement_boule_blanche[1] / 8
                    
                    while la_vitesse_absolue_de_la_balle_est_superieure_a_35():
                        
                        G["boule_blanche"].ralentissement()
                        
                    G["b"]["clic_maintenu"] = False
                    G["b"]["autorisation_de_passer_au_tour_suivant"] = True
                    
                    boule_blanche_rentree = False
                    aucune_boule_touchee = True
                    premiere_boule_touchee_verifiee = False
                    mauvaise_boule_touchee_en_premier = False
                    
                    pyxel.play(0,4)
        
        for index_objet in range(len(G["Liste_Objets"])):
            
            objet = G["Liste_Objets"][index_objet]
            objet.deplacement()
            
            for index_objet_bis in range(len(G["Liste_Objets"])):
                
                objet_bis = G["Liste_Objets"][index_objet_bis]
                
                if index_objet != index_objet_bis:
                    
                    booleen_collision = collision_cercle(objet, objet_bis)
                    
                    if booleen_collision:
                        
                        aucune_boule_touchee = False
                        
                        if objet == G["boule_blanche"] and (len(G["boules marquees"]["equipe_1"]) > 0 or len(G["boules marquees"]["equipe_2"]) > 0) and not(premiere_boule_touchee_verifiee):
                            
                            mauvaise_boule_touchee_en_premier = not((G["Equipe"] ^ G["Raye Equipe"]) ^ objet_bis.raye)
                            premiere_boule_touchee_verifiee = True
                            
                        objet.inverse_ralentissement()
                        
                        intersection_x = intersection_cercle(objet.x, objet.y, objet.x + objet.vitesse_x, objet.y + objet.vitesse_y, objet_bis.x, objet_bis.y, 25)
                        nombre_intersections = intersection_x[0]
                        
                        augmentation_du_rayon_de_verification = 0
                        
                        while nombre_intersections == 0:
                            
                            augmentation_du_rayon_de_verification += 1
                            intersection_x = intersection_cercle(objet.x, objet.y, objet.x + objet.vitesse_x, objet.y + objet.vitesse_y, objet_bis.x, objet_bis.y, 25 + augmentation_du_rayon_de_verification)
                            nombre_intersections = intersection_x[0]
                        
                        Pente = pente(objet.x, objet.y, objet.x + objet.vitesse_x, objet.y + objet.vitesse_y)
                        Ordonne_origine = ordonne_origine(objet.x, objet.y, objet.x + objet.vitesse_x, objet.y + objet.vitesse_y)
                        
                        if nombre_intersections == 1:
                            
                            intersection_x = intersection_x[1]
                            intersection_y = intersection_x * Pente + Ordonne_origine
                            
                            vecteur_centre_cercle_x = objet_bis.x - intersection_x
                            vecteur_centre_cercle_y = objet_bis.y - intersection_y
                            
                        elif nombre_intersections == 2:
                            
                            if objet.vitesse_x > 0:
                                
                                intersection_x = min_val(intersection_x[1], intersection_x[2])
                                
                            else:
                                
                                intersection_x = maxi_val(intersection_x[1], intersection_x[2])
                                    
                            intersection_y = intersection_x * Pente + Ordonne_origine
                            
                            vecteur_centre_cercle_x = objet_bis.x - intersection_x
                            vecteur_centre_cercle_y = objet_bis.y - intersection_y
                            
                        if (objet.vitesse_x**2 + objet.vitesse_y**2) == 0:
                            #Plus la valeur est petite, moins il y aura de chance que les boules finissent les une dans les autres pendant plus d'une frame
                            #Plus la valeur est haute, moins les boules se déplaceront, ce qui peut amener à des bizarreries
                            variable_O = 1
                            
                        else:
                            #Voir schéma3
                            variable_O = (vecteur_centre_cercle_x**2 + vecteur_centre_cercle_y**2)/(objet.vitesse_x**2 + objet.vitesse_y**2)
                            
                        vecteur_final_x = vecteur_centre_cercle_x
                        vecteur_final_y = vecteur_centre_cercle_y
                        
                        objet_bis.vitesse_x += vecteur_final_x/math.sqrt(variable_O) * 0.95
                        objet_bis.vitesse_y += vecteur_final_y/math.sqrt(variable_O) * 0.95
                        
                        objet.vitesse_x -= (vecteur_final_x/math.sqrt(variable_O)) * 0.70
                        objet.vitesse_y -= (vecteur_final_y/math.sqrt(variable_O)) * 0.70
                        
                        pyxel.play(0,4)
                        
            recadrement(objet, G["taille"]["fenetre_x"], G["taille"]["fenetre_y"])
            
        for objet in G["Liste_Objets"]:
            
            if test_trou(objet):
                
                pyxel.play(0,0)
                
                if not(objet == G["boule_blanche"]):
                    
                    if not(G["Equipe"]):
                        
                        if len(G["boules marquees"]["equipe_1"]) == 0 and len(G["boules marquees"]["equipe_2"]) == 0:
                            
                            G["Raye Equipe"] = not(objet.raye)
                        
                        if objet.couleur == blanc:
                            
                            if len(G["boules marquees"]["equipe_1"]) == noir:
                                
                                G["Victoire_Joueur_1"] = True
                                
                            else:
                                
                                G["Victoire_Joueur_2"] = True
                                
                    else:
                        
                        if len(G["boules marquees"]["equipe_1"]) == 0 and len(G["boules marquees"]["equipe_2"]) == 0:
                            
                            G["Raye Equipe"] = objet.raye
                            
                        if objet.couleur == blanc:
                            
                            if len(G["boules marquees"]["equipe_2"]) == noir:
                                
                                G["Victoire_Joueur_2"] = True
                                
                            else:
                                
                                G["Victoire_Joueur_1"] = True
                                
                    if G["Raye Equipe"] == objet.raye:
                        
                        objet.x = G["taille"]["fenetre_x"] - (len(G["boules marquees"]["equipe_2"]) * 25 + 15)
                        objet.y = 15
                        G["boules marquees"]["equipe_2"].append(objet)
                        
                    else:
                        
                        objet.x = len(G["boules marquees"]["equipe_1"]) * 25 + 15
                        objet.y = 15
                        G["boules marquees"]["equipe_1"].append(objet)
                        
                    G["Liste_Objets"].remove(objet)
                    G["Boule Marquee"] = (G["Equipe"] ^ G["Raye Equipe"]) ^ objet.raye
                    
                else:
                    
                    G["Liste_Objets"][0] = Boule(504 - 25 / 2, 32 + 224 - 25 / 2, 25, 0, 0)
                    G["boule_blanche"] = G["Liste_Objets"][0]
                    boule_blanche_rentree = True
                    
        if G["b"]["tour_suivant"]:
            
            if not(G["Boule Marquee"]):
                
                G["Equipe"] = not(G["Equipe"])
                G["b"]["tour_suivant"] = False
                
            else:
                
                if boule_blanche_rentree:
                    
                    G["b"]["tour_suivant"] = True
                
                else:
                    
                    G["b"]["tour_suivant"] = False
                
                G["Boule Marquee"] = False
        
        G["b"]["en_train_de_tirer"] = G["b"]["clic_maintenu"]
            
    else:
        
        if pyxel.btn(pyxel.KEY_RETURN):
            
            #Initialisation
            ##########################################
            Boule_Blanche = Boule(504 - 25 / 2, 32 + 224 - 25 / 2, 25, 0, 0)
            Triangle_Boules = [Boule_Blanche]
            espacement_x = 21.66
            espacement_y = 12.5
            x_boule_1 = 168 + 25 * 5 - 25 / 2
            y_boule_1 = 32 + 224 - 25 / 2
            numero = 0

            for rangee_x in range(5):
                
                for rangee_y in range(rangee_x + 1):
                    
                    numero += 1
                    Triangle_Boules.append(Boule(x_boule_1 - (espacement_x * rangee_x), y_boule_1 + (espacement_y * (2 * rangee_y - rangee_x)), 25, numero % 8, int(numero / 8)))

            dico_bool = {"autorisation_de_passer_au_tour_suivant": True, "tour_suivant": False, "boule_blanche_en_main": False, "en_train_de_tirer": False, "clic_maintenu": False}
            G = {"taille": {"fenetre_x": fenetre_x, "fenetre_y": fenetre_y}, "Liste_Objets": Triangle_Boules, "boule_blanche": Triangle_Boules[0], "boules marquees": {"equipe_1": [], "equipe_2": []}, "b": dico_bool, "position_curseur_origine": [0, 0], "clic": True, "Equipe": True, "Raye Equipe": True, "Boule Marquee": False, "Victoire_Joueur_1": False, "Victoire_Joueur_2": False}

            boule_blanche_rentree = False
            aucune_boule_touchee = True
            mauvaise_boule_touchee_en_premier = False
            premiere_boule_touchee_verifiee = False
            musique_ecran_victoire = True
        
        if musique_ecran_victoire:
            
            pyxel.playm(1)
            musique_ecran_victoire = False
            
def draw():

    pyxel.cls(0)
    
    if G["Victoire_Joueur_1"]:
        
        pyxel.rect(0, 0, 672, 448 + 32, 0)
        pyxel.bltm(16, 16, 0, 672 + 32, 0, 640, 448, 9)
        
    elif G["Victoire_Joueur_2"]:
        
        pyxel.rect(0, 0, 672, 448 + 32, 0)
        pyxel.bltm(16, 16, 0, 1408, 0, 640, 448, 9)
        
    else:
        
        pyxel.bltm(0, 32, 0, 0, 0, 672, 448, 9)
        
        for objet in G["Liste_Objets"]:
            
            objet.affiche()
            
        if G["b"]["en_train_de_tirer"]:
            
            vecteur_deplacement_boule_blanche = [(G["position_du_curseur_au_debut_du_tir"][0] - pyxel.mouse_x) / 8, (G["position_du_curseur_au_debut_du_tir"][1] - pyxel.mouse_y) / 8]
            while abs(vecteur_deplacement_boule_blanche[0]) > 35 or abs(vecteur_deplacement_boule_blanche[1]) > 35:
                
                vecteur_deplacement_boule_blanche[0], vecteur_deplacement_boule_blanche[1] = ralentissement(vecteur_deplacement_boule_blanche[0], vecteur_deplacement_boule_blanche[1])
            
            angle = angle_entre_la_souris_et_la_boule_blanche(vecteur_deplacement_boule_blanche)
            pyxel.tri(G["position_boule_blanche"][0] + 3 * math.cos(angle + math.pi / 2), G["position_boule_blanche"][1] + 3 * math.sin(angle + math.pi / 2), G["position_boule_blanche"][0] + 2 * math.cos(angle - math.pi / 2), G["position_boule_blanche"][1] + 2 * math.sin(angle - math.pi / 2), G["position_boule_blanche"][0] + vecteur_deplacement_boule_blanche[0] * 6, G["position_boule_blanche"][1] + vecteur_deplacement_boule_blanche[1] * 6, 8)

        if G["Equipe"]:
            
            pyxel.blt(G["taille"]["fenetre_x"] - (177.5 + 15.625) - 25, 0, 0, 160, 0, 32, 32, 15)
            pyxel.blt(177.5 + 15.625, 0, 0, 128, 32, 32, 32, 9)
            
        else:
            
            pyxel.blt(177.5 + 15.625, 0, 0, 160, 32, 32, 32, 9)
            pyxel.blt(G["taille"]["fenetre_x"] - (177.5 + 15.625) - 25, 0, 0, 128, 0, 32, 32, 15)
            
        if len(G["boules marquees"]["equipe_1"]) == 7:
            
            pyxel.blt(177.5 + 32 + 15.625*2, 0, 0, 224, 32, 32, 32, 1)
            
        else:
            
            pyxel.blt(177.5 + 32 + 15.625*2, 0, 0, 224, 0, 32, 32, 1)
            
        if len(G["boules marquees"]["equipe_2"]) == 7:
            
            pyxel.blt(G["taille"]["fenetre_x"] - 32 - (177.5 + 32 + 15.625*2), 0, 0, 224, 32, 32, 32, 1)
            
        else:
            
            pyxel.blt(G["taille"]["fenetre_x"] - 32 - (177.5 + 32 + 15.625*2), 0, 0, 224, 0, 32, 32, 1)
            
        pyxel.blt(G["taille"]["fenetre_x"]/2 - 16 + (len(G["boules marquees"]["equipe_2"]) - len(G["boules marquees"]["equipe_1"])) * 4, 0, 0, 152, 184, 32, 32, 7)
        
        for numero_case_boule in range(7):
            
            pyxel.blt(15 - 12.5 + 25 * numero_case_boule, 15 - 12.5, 0, 152, 152, 25, 25, 1)
            pyxel.blt(G["taille"]["fenetre_x"] - 25 - (15 - 12.5 + 25 * numero_case_boule), 15 - 12.5, 0, 152, 152, 25, 25, 1)
            
        for boule in G["boules marquees"]["equipe_1"]:
            
            boule.affiche()
            
        for boule in G["boules marquees"]["equipe_2"]:
            
            boule.affiche()
            
pyxel.run(update, draw)